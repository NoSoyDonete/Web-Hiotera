# Estación meteorológica Hiotera · modelo 3D y animación web

Primera recreación visual de la estación a partir de las 61 fotografías proporcionadas. Las proporciones se han estimado visualmente: no es un modelo acotado para fabricación ni un escaneado por fotogrametría.

## Qué incluye

- Un modelo 3D real que se puede girar y acercar.
- Una secuencia automática: 2,5 segundos montada y 4 segundos de separación.
- Siete conjuntos seleccionables con explicaciones en español.
- Control manual de la separación y botones de montaje, despiece y repetición.
- Anemómetro y veleta animados, con opción de detener el viento.
- Vistas de perspectiva, superior y frontal.
- Diseño adaptable a ordenador y móvil. Respeta la preferencia de movimiento reducido.
- GLB de aproximadamente 4,7 MB con geometría, materiales, etiqueta y tres animaciones: `Despiece`, `Montaje` y `Viento`.

Los grupos principales son `Anemometro`, `Veleta`, `Embudo_colector`, `Cuerpo_pluviometro`, `Garita_de_lamas`, `Chasis_en_Y` y `Soporte_y_abrazaderas`. Los nombres se conservan dentro del GLB. El chasis permanece como referencia central durante el despiece; los otros seis conjuntos se desplazan.

Las etiquetas y controles interactivos pertenecen a la demo HTML/JavaScript. Un visor que abra únicamente el GLB mostrará el modelo y podrá reproducir sus animaciones, pero no los textos de la página.

## Integración en tu web

1. Sube todos los archivos de esta carpeta a una ruta de tu alojamiento, por ejemplo `/meteo-3d/`.
2. Mantén las rutas relativas y la carpeta `vendor`.
3. Añade este bloque a la página donde quieras mostrarlo:

```html
<style>
  .meteo-3d { width: 100%; height: 660px; border: 0; display: block; }
  @media (max-width: 720px) { .meteo-3d { height: 870px; } }
</style>
<iframe class="meteo-3d"
  src="/meteo-3d/index.html?embed=1"
  title="Estación meteorológica 3D: montaje y despiece"
  loading="lazy">
</iframe>
```

`?embed=1` muestra solo el explorador. Sin ese parámetro aparece la presentación completa. El enlace privado de demostración de Sites es para revisar el resultado; para usarlo en una web pública, aloja estos archivos en tu propio sitio.

No necesita una cuenta, base de datos ni conexión con servicios externos. Three.js está incluido localmente bajo licencia MIT. El alojamiento debe servir los módulos `.js` con el tipo de contenido JavaScript. Los navegadores actuales con WebGL son compatibles.

## Vista local

Los módulos JavaScript deben abrirse desde un servidor HTTP, no haciendo doble clic en el HTML. Si tienes Node.js instalado, ejecuta `node servidor.mjs` desde esta carpeta y abre `http://127.0.0.1:4173`.

## Cambiar piezas y textos

- `station-model.js`: geometría, materiales, agrupación y desplazamientos del despiece. Exporta `createStation()`.
- `app.js`: explicaciones, cámaras, controles y secuencia automática.
- `styles.css`: presentación y comportamiento adaptable.
- `hiotera-label.png`: recreación gráfica de la etiqueta visible en las fotos. No se ha reproducido un QR ficticio.
- `estacion-meteo.glb`: modelo independiente con las animaciones exportadas.

En una integración propia con Three.js puedes usar `createStation()` y llamar a `setExplosion(t)` con un valor de 0 (montada) a 1 (separada). `parts` contiene los grupos, `rotor` y `vane` las piezas giratorias y `anchors` los puntos de etiquetado. Los puntos se expresan en el sistema local de cada grupo. La geometría y el GLB son entregas independientes: si editas la geometría del JavaScript tendrás que volver a exportar el GLB para actualizarlo.

## Fidelidad y alcance

Se han recreado el cuerpo en Y, las cazoletas huecas, la veleta en cruz, el embudo, la carcasa y el balancín interior del pluviómetro, las lamas y el soporte perforado con abrazaderas. Los pequeños postes blancos superiores se conservan visualmente sin asignarles una función que no pueda confirmarse con las fotos. La representación del mecanismo interior es simplificada. No se han añadido especificaciones de precisión, comunicación o alcance.
