import * as THREE from 'three';
import { OrbitControls } from 'three/addons/controls/OrbitControls.js';
import { RoomEnvironment } from 'three/addons/environments/RoomEnvironment.js';
import { createStation } from './station-model.js';

const entries = [
  {key:'anemometer',name:'Anemómetro',short:'Anemómetro',category:'VIENTO · VELOCIDAD',symbol:'≋',copy:'Las tres cazoletas giran con el viento. Su velocidad de giro permite medir la velocidad del aire.',unit:'km/h · m/s',tag:'INSTRUMENTO DE MEDIDA'},
  {key:'vane',name:'Veleta',short:'Veleta',category:'VIENTO · DIRECCIÓN',symbol:'↗',copy:'Se orienta con el viento para indicar de qué dirección sopla. La cola mantiene la flecha alineada con el flujo de aire.',unit:'Dirección · grados',tag:'INSTRUMENTO DE MEDIDA'},
  {key:'funnel',name:'Embudo colector',short:'Embudo',category:'LLUVIA · CAPTACIÓN',symbol:'⌄',copy:'Recoge la lluvia y la conduce por su abertura central hacia el mecanismo de medida que hay en el interior.',unit:'Captación de lluvia',tag:'SISTEMA COLECTOR'},
  {key:'rain',name:'Pluviómetro',short:'Pluviómetro',category:'LLUVIA · PRECIPITACIÓN',symbol:'⋮',copy:'El agua hace bascular un pequeño balancín interior. Sus movimientos permiten calcular la precipitación acumulada. Separa el embudo para verlo.',unit:'Precipitación · mm',tag:'INSTRUMENTO DE MEDIDA'},
  {key:'shield',name:'Garita de protección',short:'Garita',category:'AIRE · PROTECCIÓN',symbol:'☰',copy:'Sus lamas dejan circular el aire y reducen el efecto del sol directo sobre el sensor de temperatura y humedad que protege.',unit:'Temperatura y humedad',tag:'PROTECCIÓN DEL SENSOR'},
  {key:'chassis',name:'Cuerpo y brazos',short:'Cuerpo',category:'ESTRUCTURA · DISTRIBUCIÓN',symbol:'⑂',copy:'El cuerpo en forma de Y sostiene los instrumentos y mantiene separados los puntos de observación. El pequeño nivel ayuda a colocar el conjunto horizontal.',unit:'Estructura del conjunto',tag:'CUERPO PRINCIPAL'},
  {key:'mount',name:'Soporte y fijación',short:'Soporte',category:'MONTAJE · ESTABILIDAD',symbol:'⌁',copy:'El perfil metálico y las dos abrazaderas sujetan la estación. La base perforada permite fijar el soporte a una superficie.',unit:'Sujeción mecánica',tag:'SISTEMA DE FIJACIÓN'}
];
const $=id=>document.getElementById(id);
const reduced=matchMedia('(prefers-reduced-motion: reduce)').matches;
let index=0, value=0, playing=false, windOn=!reduced, phase=0, runStart=0, transition=null;
const stage=$('stage'), host=$('scene'), hotspotElements=[];

function selectPart(i, announce=true){
  index=(i+entries.length)%entries.length;
  const e=entries[index];
  $('part-count').textContent=`${String(index+1).padStart(2,'0')} / 07`;
  $('part-symbol').textContent=e.symbol;
  $('part-category').textContent=e.category;
  $('part-title').textContent=e.name;
  $('part-copy').textContent=e.copy;
  $('part-unit').textContent=e.unit;
  $('part-tag').textContent=e.tag;
  document.querySelectorAll('[data-part-index]').forEach(el=>{const active=Number(el.dataset.partIndex)===index;el.classList.toggle('active',active);el.setAttribute('aria-pressed',String(active));});
  if(announce)$('announcer').textContent=`${e.name}. ${e.copy}`;
}
entries.forEach((e,i)=>{
  const dot=document.createElement('button');dot.dataset.partIndex=i;dot.title=e.name;dot.setAttribute('aria-label',e.name);dot.onclick=()=>selectPart(i);$('part-dots').append(dot);
  const chip=document.createElement('button');chip.dataset.partIndex=i;chip.className='part-chip';chip.innerHTML=`<span>${String(i+1).padStart(2,'0')}</span>${e.short}`;chip.onclick=()=>selectPart(i);$('parts-list').append(chip);
  const hot=document.createElement('button');hot.dataset.partIndex=i;hot.dataset.label=e.name;hot.className='hotspot';hot.textContent=String(i+1).padStart(2,'0');hot.setAttribute('aria-label',`Ver ${e.name}`);hot.onclick=()=>{stop();selectPart(i);};$('hotspots').append(hot);hotspotElements.push(hot);
});
$('prev-part').onclick=()=>selectPart(index-1);
$('next-part').onclick=()=>selectPart(index+1);
selectPart(0,false);

function setValue(v){
  value=THREE.MathUtils.clamp(v,0,1);
  station?.setExplosion(value);
  $('explode').value=String(value*100);
  $('explode').style.setProperty('--progress',`${value*100}%`);
  $('progress').textContent=`${Math.round(value*100)}%`;
  $('view-state').textContent=value<.02?'VISTA MONTADA':value>.98?'VISTA EN DESPIECE':'SEPARANDO PIEZAS';
  $('transport-label').textContent=value<.02?'Descubre su interior':value>.98?'Cada pieza, al descubierto':'Explorando la estación';
}
function stop(){playing=false;transition=null;$('play-icon').textContent='▶';$('play').setAttribute('aria-label','Reproducir animación de despiece');}
function play(){transition=null;playing=true;runStart=performance.now();phase=value<.03?0:1;$('play-icon').textContent='Ⅱ';$('play').setAttribute('aria-label','Pausar animación');if(value>.03)setValue(0);}
function animateTo(target){stop();transition={from:value,to:target,start:performance.now(),duration:reduced?0:1800};}
$('play').onclick=()=>playing?stop():play();
$('assemble').onclick=()=>animateTo(0);
$('disassemble').onclick=()=>animateTo(1);
$('explode').addEventListener('input',e=>{stop();setValue(Number(e.target.value)/100);});
$('wind').setAttribute('aria-pressed',String(windOn));
$('wind').onclick=()=>{windOn=!windOn;$('wind').setAttribute('aria-pressed',String(windOn));};

let station, renderer, scene, camera, controls;
try {
  renderer=new THREE.WebGLRenderer({antialias:true,alpha:true,powerPreference:'high-performance'});
  renderer.setPixelRatio(Math.min(devicePixelRatio,1.5));
  renderer.shadowMap.enabled=true;renderer.shadowMap.type=THREE.PCFSoftShadowMap;
  renderer.outputColorSpace=THREE.SRGBColorSpace;renderer.toneMapping=THREE.ACESFilmicToneMapping;renderer.toneMappingExposure=1.05;
  renderer.domElement.setAttribute('aria-label','Modelo tridimensional giratorio');
  host.appendChild(renderer.domElement);
  scene=new THREE.Scene();
  const pmrem=new THREE.PMREMGenerator(renderer);
  const environment=new RoomEnvironment();scene.environment=pmrem.fromScene(environment,.04).texture;scene.environmentIntensity=.65;environment.dispose();pmrem.dispose();
  scene.add(new THREE.HemisphereLight(0xf5f8ee,0x8d947f,1.2));
  const key=new THREE.DirectionalLight(0xfffcf1,2.6);key.position.set(-3,10,4);key.castShadow=true;key.shadow.mapSize.set(1024,1024);key.shadow.camera.left=-4;key.shadow.camera.right=4;key.shadow.camera.top=5;key.shadow.camera.bottom=-4;key.shadow.normalBias=.025;key.shadow.bias=-.00015;key.shadow.radius=4;scene.add(key);
  const fill=new THREE.DirectionalLight(0xe5edfc,1.1);fill.position.set(4,4,-4);scene.add(fill);
  const bounce=new THREE.DirectionalLight(0xf5f6e8,.5);bounce.position.set(0,1,5);scene.add(bounce);
  station=createStation();scene.add(station.root);
  new THREE.TextureLoader().load('hiotera-label.png',texture=>{texture.colorSpace=THREE.SRGBColorSpace;texture.anisotropy=renderer.capabilities.getMaxAnisotropy();station.root.traverse(o=>{if(o.material?.name==='Hiotera_Label'){o.material.map=texture;o.material.needsUpdate=true;}});});
  const ground=new THREE.Mesh(new THREE.PlaneGeometry(200,200),new THREE.ShadowMaterial({color:0x5d6749,opacity:.16}));ground.rotation.x=-Math.PI/2;ground.position.y=-.035;ground.receiveShadow=true;scene.add(ground);
  const shadowTexture=new THREE.CanvasTexture((()=>{const c=document.createElement('canvas');c.width=c.height=128;const cx=c.getContext('2d'),g=cx.createRadialGradient(64,64,0,64,64,64);g.addColorStop(0,'rgba(74,86,50,.15)');g.addColorStop(.35,'rgba(74,86,50,.07)');g.addColorStop(1,'rgba(74,86,50,0)');cx.fillStyle=g;cx.fillRect(0,0,128,128);return c;})());
  const contact=new THREE.Mesh(new THREE.PlaneGeometry(2.5,1.9),new THREE.MeshBasicMaterial({map:shadowTexture,transparent:true,depthWrite:false}));contact.rotation.x=-Math.PI/2;contact.position.y=-.028;scene.add(contact);
  camera=new THREE.PerspectiveCamera(34,1,.01,100);
  controls=new OrbitControls(camera,renderer.domElement);controls.enableDamping=true;controls.dampingFactor=.07;controls.enablePan=false;controls.minDistance=3;controls.maxDistance=26;controls.minPolarAngle=.02;controls.maxPolarAngle=Math.PI*.80;controls.target.set(0,1.63,-.22);
  let camTween=null;
  function preset(name,immediate=false){
    const aspect=stage.clientWidth/stage.clientHeight;const positions={perspective:[-3.8,4.7,-5.6],top:[.01,8.8,.4],front:[.1,2.9,-8.2]};
    const to=new THREE.Vector3(...positions[name]);
    const target=new THREE.Vector3(0,1.63,-.22);
    const factor=Math.max(.96,1.5/aspect);to.sub(target).multiplyScalar(factor).add(target);
    if(immediate||reduced){camera.position.copy(to);controls.target.copy(target);controls.update();camTween=null;}
    else camTween={start:performance.now(),from:camera.position.clone(),to,fromTarget:controls.target.clone(),target};
    document.querySelectorAll('[data-view]').forEach(el=>el.classList.toggle('active',el.dataset.view===name));
  }
  document.querySelectorAll('[data-view]').forEach(el=>el.onclick=()=>preset(el.dataset.view));
  $('reset').onclick=()=>{stop();preset('perspective');animateTo(0);selectPart(0);};
  controls.addEventListener('start',()=>{camTween=null;document.querySelectorAll('[data-view]').forEach(el=>el.classList.remove('active'));});
  // A click on a physical component selects its explanation; dragging remains an orbit gesture.
  const raycaster=new THREE.Raycaster();let down=null;
  renderer.domElement.addEventListener('pointerdown',e=>{down={x:e.clientX,y:e.clientY};});
  renderer.domElement.addEventListener('pointerup',e=>{if(!down||Math.hypot(e.clientX-down.x,e.clientY-down.y)>6)return;const rect=host.getBoundingClientRect();raycaster.setFromCamera(new THREE.Vector2((e.clientX-rect.left)/rect.width*2-1,-(e.clientY-rect.top)/rect.height*2+1),camera);const hit=raycaster.intersectObject(station.root,true)[0];if(hit){let o=hit.object;while(o&&!o.userData.part)o=o.parent;const i=entries.findIndex(x=>x.key===o?.userData.part);if(i>=0){stop();selectPart(i);}}});
  let previousAspect=0;
  const resize=()=>{const w=host.clientWidth,h=host.clientHeight;renderer.setSize(w,h,false);camera.aspect=w/h;camera.updateProjectionMatrix();if(previousAspect&&Math.abs(previousAspect-w/h)>.35)preset('perspective',true);previousAspect=w/h;};
  new ResizeObserver(resize).observe(host);resize();preset('perspective',true);
  $('loading').style.display='none';
  let previous=performance.now(),elapsed=0;
  const projected=new THREE.Vector3();
  function frame(now){
    if(now-previous<32||document.hidden){requestAnimationFrame(frame);return;}
    const dt=Math.min((now-previous)/1000,.05);previous=now;elapsed+=dt;
    if(playing){const seconds=(now-runStart)/1000;if(seconds<2.5){setValue(0);}else if(seconds<6.5){const t=(seconds-2.5)/4;setValue(t*t*(3-2*t));}else{setValue(1);stop();$('announcer').textContent='Despiece completo. Selecciona una pieza para conocer su función.';}}
    if(transition){const t=transition.duration===0?1:Math.min((now-transition.start)/transition.duration,1);const smooth=t*t*(3-2*t);setValue(THREE.MathUtils.lerp(transition.from,transition.to,smooth));if(t===1)transition=null;}
    if(camTween){const t=Math.min((now-camTween.start)/900,1),s=t*t*(3-2*t);camera.position.lerpVectors(camTween.from,camTween.to,s);controls.target.lerpVectors(camTween.fromTarget,camTween.target,s);if(t===1)camTween=null;}
    if(windOn){station.rotor.rotation.y+=dt*1.25;station.vane.rotation.y=-.18+Math.sin(elapsed*.45)*.12;}
    ground.position.y=-.035-value*.31;contact.position.y=-.028-value*.31;contact.material.opacity=1-value*.7;
    controls.update();station.root.updateMatrixWorld(true);
    const w=host.clientWidth,h=host.clientHeight;
    entries.forEach((e,i)=>{projected.copy(station.anchors[e.key]);station.parts[e.key].localToWorld(projected);projected.project(camera);const el=hotspotElements[i];el.style.left=`${(projected.x*.5+.5)*w}px`;el.style.top=`${(-projected.y*.5+.5)*h}px`;const visible=projected.z<1&&projected.z>-1&&Math.abs(projected.x)<.95&&Math.abs(projected.y)<.96;el.style.visibility=visible?'visible':'hidden';});
    renderer.render(scene,camera);requestAnimationFrame(frame);
  }
  requestAnimationFrame(frame);
  if(!reduced)play();
  window.meteo={station,setExplosion:v=>{stop();setValue(v);},selectPart,preset,renderer,scene,camera,controls,get progress(){return value;},get playing(){return playing;},get selected(){return entries[index].key;}};
  renderer.domElement.addEventListener('webglcontextlost',()=>{stop();$('loading').textContent='La vista 3D se ha interrumpido. Recarga la página para continuar.';$('loading').style.display='flex';});
} catch(error){
  console.error(error);$('loading').classList.add('error');$('loading').textContent='No se ha podido abrir el modelo 3D. Usa un navegador actualizado con WebGL activado. Puedes descargar el archivo GLB desde el enlace inferior.';
}
