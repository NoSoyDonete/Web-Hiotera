import * as THREE from 'three';
import { RoundedBoxGeometry } from 'three/addons/geometries/RoundedBoxGeometry.js';

/** A lightweight, separately articulated reconstruction from the supplied photographs.
 * Coordinates are proportional, not measured engineering dimensions. */
export function createStation() {
  const root = new THREE.Group();
  root.name = 'Estacion_meteorologica_Hiotera';
  root.userData = { description: 'Reconstrucción visual de las fotografías. Escala aproximada.' };
  const white = new THREE.MeshPhysicalMaterial({color:0xf5f5f0,roughness:.28,metalness:.02,clearcoat:.45,clearcoatRoughness:.22});
  const ivory = new THREE.MeshStandardMaterial({color:0xcecfc2,roughness:.47,metalness:0});
  const black = new THREE.MeshPhysicalMaterial({color:0x111419,roughness:.20,metalness:.06,clearcoat:.8,clearcoatRoughness:.14});
  const innerBlack = new THREE.MeshPhysicalMaterial({color:0x0b0e12,roughness:.25,metalness:.04,clearcoat:.65,side:THREE.DoubleSide});
  const silver = new THREE.MeshStandardMaterial({color:0xa8b6bd,roughness:.27,metalness:.93});
  const darkSilver = new THREE.MeshStandardMaterial({color:0x7a898f,roughness:.40,metalness:.9});
  const rubber = new THREE.MeshStandardMaterial({color:0x272b2a,roughness:.87});
  const glass = new THREE.MeshPhysicalMaterial({color:0xd8e3d8,roughness:.12,transparent:true,opacity:.68,metalness:.02,clearcoat:1});
  const sensorFace = new THREE.MeshStandardMaterial({color:0xd6e1d9,roughness:.31});
  let serial=0;
  const parts={};
  const assembled={};
  const offsets={anemometer:new THREE.Vector3(-.48,.68,.1),vane:new THREE.Vector3(.48,.65,.1),funnel:new THREE.Vector3(0,.94,-.24),rain:new THREE.Vector3(0,.13,-.30),shield:new THREE.Vector3(.32,-.49,-.12),chassis:new THREE.Vector3(0,0,0),mount:new THREE.Vector3(0,-.30,.12)};
  function part(key,name,pos){const g=new THREE.Group();g.name=name;g.position.set(...pos);g.userData.part=key;root.add(g);parts[key]=g;assembled[key]=g.position.clone();return g;}
  function mesh(parent,geo,mat,pos=[0,0,0],name='Detalle'){const m=new THREE.Mesh(geo,mat);m.name=`${name}_${++serial}`;m.position.set(...pos);m.castShadow=true;m.receiveShadow=true;parent.add(m);return m;}
  function box(parent,w,h,d,mat,pos,name='Carcasa',radius=.014){return mesh(parent,new RoundedBoxGeometry(w,h,d,3,Math.min(radius,w/3,h/3,d/3)),mat,pos,name);}
  function cylinder(parent,rt,rb,h,mat,pos,name='Eje',segments=40){return mesh(parent,new THREE.CylinderGeometry(rt,rb,h,segments),mat,pos,name);}
  function lathe(parent,profile,mat,pos,name,segments=80){return mesh(parent,new THREE.LatheGeometry(profile.map(p=>new THREE.Vector2(...p)),segments),mat,pos,name);}
  function rod(parent,a,b,r,mat,name='Varilla',segments=12){const va=new THREE.Vector3(...a),vb=new THREE.Vector3(...b),v=vb.clone().sub(va);const m=mesh(parent,new THREE.CylinderGeometry(r,r,v.length(),segments),mat,va.clone().add(vb).multiplyScalar(.5).toArray(),name);m.quaternion.setFromUnitVectors(new THREE.Vector3(0,1,0),v.normalize());return m;}
  function ring(parent,r,tube,mat,pos,name='Aro'){const m=mesh(parent,new THREE.TorusGeometry(r,tube,8,64),mat,pos,name);m.rotation.x=Math.PI/2;return m;}
  function horizontalShape(parent,coords,depth,mat,y,name,bevel=.008){const sh=new THREE.Shape();coords.forEach(([x,z],i)=>i?sh.lineTo(x,-z):sh.moveTo(x,-z));sh.closePath();const geo=new THREE.ExtrudeGeometry(sh,{depth,bevelEnabled:bevel>0,bevelSegments:2,steps:1,bevelSize:bevel,bevelThickness:bevel});const m=mesh(parent,geo,mat,[0,y,0],name);m.rotation.x=-Math.PI/2;return m;}
  function screw(parent,pos,axis='y',radius=.018){const s=cylinder(parent,radius,radius,.011,silver,pos,'Tornillo',20);if(axis==='z')s.rotation.x=Math.PI/2;if(axis==='x')s.rotation.z=Math.PI/2;box(s,radius*1.22,.0018,.0035,darkSilver,[0,.0065,0],'Ranura',.0005);return s;}

  // The perforated, folded steel profile and its slotted foot are modeled with true holes.
  const mount=part('mount','Soporte_y_abrazaderas',[0,0,0]);
  const mastShape=new THREE.Shape();mastShape.moveTo(-.069,.065);mastShape.lineTo(.069,.065);mastShape.lineTo(.069,1.665);mastShape.lineTo(-.069,1.665);mastShape.closePath();
  for(let i=0;i<7;i++){const y=.18+i*.204;const p=new THREE.Path();if(i%2===0){p.absellipse(0,y,.027,.027,0,Math.PI*2,true,0);}else{const r=.021,h=.033;p.moveTo(-r,y-h);p.lineTo(-r,y+h);p.absarc(0,y+h,r,Math.PI,0,true);p.lineTo(r,y-h);p.absarc(0,y-h,r,0,-Math.PI,true);p.closePath();}mastShape.holes.push(p);}
  const mastGeo=new THREE.ExtrudeGeometry(mastShape,{depth:.018,bevelEnabled:true,bevelSize:.002,bevelThickness:.002,bevelSegments:1,steps:1});
  mesh(mount,mastGeo,silver,[0,0,.035],'Perfil_perforado');
  box(mount,.014,1.60,.108,silver,[-.069,.865,-.011],'Pliegue_izquierdo',.002);
  box(mount,.014,1.60,.108,silver,[.069,.865,-.011],'Pliegue_derecho',.002);
  const footShape=new THREE.Shape();const fw=.36,fd=.135,fr=.022;footShape.moveTo(-fw+fr,-fd);footShape.lineTo(fw-fr,-fd);footShape.quadraticCurveTo(fw,-fd,fw,-fd+fr);footShape.lineTo(fw,fd-fr);footShape.quadraticCurveTo(fw,fd,fw-fr,fd);footShape.lineTo(-fw+fr,fd);footShape.quadraticCurveTo(-fw,fd,-fw,fd-fr);footShape.lineTo(-fw,-fd+fr);footShape.quadraticCurveTo(-fw,-fd,-fw+fr,-fd);
  for(const x of [-.265,.265]){const p=new THREE.Path();const r=.026,h=.020;p.moveTo(x-r,-h);p.lineTo(x-r,h);p.absarc(x,h,r,Math.PI,0,true);p.lineTo(x+r,-h);p.absarc(x,-h,r,0,-Math.PI,true);p.closePath();footShape.holes.push(p);}
  const footGeo=new THREE.ExtrudeGeometry(footShape,{depth:.016,bevelEnabled:true,bevelSegments:2,bevelSize:.004,bevelThickness:.004,steps:1});
  const foot=mesh(mount,footGeo,silver,[0,.022,0],'Pletina_base_ranurada');foot.rotation.x=-Math.PI/2;
  box(mount,.18,.025,.13,darkSilver,[0,.07,-.005],'Soldadura',.006);
  box(mount,.34,.27,.021,silver,[0,1.49,.18],'Placa_abrazadera',.009);
  for(const y of [1.40,1.58]){
    const curve=new THREE.CatmullRomCurve3([new THREE.Vector3(-.125,y,.32),new THREE.Vector3(-.125,y,-.07),new THREE.Vector3(-.09,y,-.13),new THREE.Vector3(.09,y,-.13),new THREE.Vector3(.125,y,-.07),new THREE.Vector3(.125,y,.32)],false,'centripetal');
    mesh(mount,new THREE.TubeGeometry(curve,35,.014,10,false),silver,[0,0,0],'Abrazadera_U');
    for(const x of [-.125,.125]){
      const washer=cylinder(mount,.033,.033,.009,silver,[x,y,.205],'Arandela');washer.rotation.x=Math.PI/2;
      const nut=cylinder(mount,.026,.026,.025,darkSilver,[x,y,.225],'Tuerca',6);nut.rotation.x=Math.PI/2;
      for(let j=0;j<10;j++){const th=ring(mount,.014,.0018,darkSilver,[x,y,.247+j*.007],'Rosca');th.rotation.x=0;}
    }
  }

  const chassis=part('chassis','Chasis_en_Y',[0,1.76,0]);
  const outline=[[-.17,-.92],[.17,-.92],[.18,-.14],[1.21,.205],[1.30,.26],[1.33,.45],[1.25,.55],[1.10,.55],[0,.18],[-1.10,.55],[-1.25,.55],[-1.33,.45],[-1.30,.26],[-1.21,.205],[-.18,-.14]];
  horizontalShape(chassis,outline,.045,black,-.074,'Chasis_inferior',.009);
  horizontalShape(chassis,outline,.091,white,-.023,'Chasis_blanco',.009);
  box(chassis,.40,.095,.36,black,[0,-.12,-.015],'Cabezal_de_sujecion',.025);
  // Subtle raised ridge, matching the folded-looking upper surfaces of the photographed arms.
  for(const sign of [-1,1]){
    const pts=[0,.082,.025, sign*1.095,.082,.39, sign*1.095,.048,.535, 0,.048,.18, sign*1.095,.048,.235, 0,.048,-.13];
    const indices=sign>0?[0,2,1,0,3,2,0,1,4,0,4,5]:[0,1,2,0,2,3,0,4,1,0,5,4];
    const geo=new THREE.BufferGeometry();geo.setAttribute('position',new THREE.Float32BufferAttribute(pts,3));geo.setIndex(indices);geo.computeVertexNormals();mesh(chassis,geo,white,[0,0,0],'Lomo_del_brazo');
    const cap=box(chassis,.39,.074,.34,black,[sign*1.30,.014,.39],'Extremo_negro',.065);cap.rotation.y=-sign*.32;
    cylinder(chassis,.079,.104,.47,black,[sign*1.32,.29,.40],'Torre_conica');
    cylinder(chassis,.111,.111,.045,black,[sign*1.32,.078,.40],'Base_torre');
    cylinder(chassis,.033,.033,.065,silver,[sign*1.32,.555,.40],'Eje_metalico');
    screw(chassis,[sign*1.30,-.105,.40]);
  }
  // Two small upper posts retained from the references; no unverified sensor function is asserted.
  cylinder(chassis,.052,.075,.235,white,[0,.193,-.16],'Poste_blanco_grande');
  cylinder(chassis,.045,.045,.007,sensorFace,[0,.313,-.16],'Superficie_sensor');
  ring(chassis,.049,.005,white,[0,.318,-.16],'Borde_sensor');
  cylinder(chassis,.024,.034,.123,white,[-.238,.133,-.044],'Poste_blanco_pequeno');
  cylinder(chassis,.020,.020,.004,sensorFace,[-.238,.196,-.044],'Tapa_sensor_pequeno');
  cylinder(chassis,.065,.065,.020,white,[0,.082,-.679],'Nivel_circular');
  cylinder(chassis,.050,.050,.008,glass,[0,.097,-.679],'Cristal_nivel');
  ring(chassis,.036,.0017,darkSilver,[0,.103,-.679],'Circulo_del_nivel');
  const bubble=mesh(chassis,new THREE.SphereGeometry(.012,16,8),glass,[.005,.106,-.679],'Burbuja');bubble.scale.y=.24;
  // Battery lid seam on the rain-facing branch.
  box(chassis,.291,.0015,.401,rubber,[0,.079,-.452],'Tapa_compartimento',.018);
  box(chassis,.278,.002,.388,black,[0,.081,-.452],'Panel_superior',.016);
  for(const x of [-.11,.11])screw(chassis,[x,-.082,-.44]);

  // Three hollow cups; all openings are vertical and tangent to the circle of rotation.
  const anemometer=part('anemometer','Anemometro',[-1.32,2.345,.40]);
  const rotor=new THREE.Group();rotor.name='Rotor_anemometro';anemometer.add(rotor);
  cylinder(rotor,.099,.099,.088,black,[0,0,0],'Buje_rotor');
  cylinder(rotor,.092,.099,.015,black,[0,.049,0],'Tapa_buje');
  screw(rotor,[0,.061,0], 'y',.013);
  const cupProfile=[[0,-.167],[.063,-.153],[.119,-.120],[.162,-.073],[.181,-.026],[.184,0],[.175,.002],[.171,-.023],[.152,-.065],[.111,-.107],[.058,-.137],[0,-.146]];
  for(let i=0;i<3;i++){
    const a=i*Math.PI*2/3;const radial=new THREE.Vector3(Math.cos(a),0,Math.sin(a));const tangent=new THREE.Vector3(-Math.sin(a),0,Math.cos(a));
    const arm=box(rotor,.363,.022,.034,black,radial.clone().multiplyScalar(.254).toArray(),'Brazo_cazoleta',.004);arm.rotation.y=-a;
    const cupGroup=new THREE.Group();cupGroup.name=`Cazoleta_hueca_${i+1}`;cupGroup.position.copy(radial.clone().multiplyScalar(.443));cupGroup.quaternion.setFromUnitVectors(new THREE.Vector3(0,1,0),tangent);rotor.add(cupGroup);
    lathe(cupGroup,cupProfile,innerBlack,[0,0,0],'Hemisferio_hueco',56);
    ring(cupGroup,.18,.0045,black,[0,.001,0],'Labio_cazoleta');
  }

  const vanePart=part('vane','Veleta',[1.32,2.345,.40]);
  const vane=new THREE.Group();vane.name='Rotor_veleta';vanePart.add(vane);vane.rotation.y=-.18;
  cylinder(vane,.099,.099,.087,black,[0,0,0],'Buje_veleta');
  cylinder(vane,.096,.099,.012,black,[0,.050,0],'Tapa_veleta');
  rod(vane,[-.59,.025,0],[.57,.025,0],.013,black,'Eje_flecha');
  box(vane,.42,.022,.035,black,[.29,.025,0],'Nervio_flecha',.005);
  const arrowShape=new THREE.Shape();arrowShape.moveTo(.665,0);arrowShape.lineTo(.51,-.057);arrowShape.lineTo(.525,0);arrowShape.lineTo(.51,.057);arrowShape.closePath();
  const arrowGeo=new THREE.ExtrudeGeometry(arrowShape,{depth:.012,bevelEnabled:true,bevelSize:.003,bevelThickness:.003,steps:1,bevelSegments:1});
  const arrow=mesh(vane,arrowGeo,black,[0,.029,.006],'Punta_flecha');arrow.rotation.x=Math.PI/2;
  const tailShape=new THREE.Shape();tailShape.moveTo(-.11,.027);tailShape.lineTo(-.345,.245);tailShape.quadraticCurveTo(-.367,.265,-.39,.265);tailShape.lineTo(-.61,.265);tailShape.quadraticCurveTo(-.63,.265,-.63,.235);tailShape.lineTo(-.605,-.11);tailShape.quadraticCurveTo(-.60,-.133,-.575,-.133);tailShape.lineTo(-.36,-.133);tailShape.closePath();
  const tailGeo=new THREE.ExtrudeGeometry(tailShape,{depth:.010,bevelEnabled:true,bevelSize:.004,bevelThickness:.003,bevelSegments:2,steps:1});
  mesh(vane,tailGeo,black,[0,0,-.005],'Aleta_vertical');
  const crossShape=new THREE.Shape();crossShape.moveTo(-.11,0);crossShape.lineTo(-.38,.148);crossShape.quadraticCurveTo(-.40,.158,-.43,.158);crossShape.lineTo(-.61,.158);crossShape.quadraticCurveTo(-.63,.158,-.63,.13);crossShape.lineTo(-.61,-.13);crossShape.quadraticCurveTo(-.61,-.15,-.58,-.15);crossShape.lineTo(-.40,-.15);crossShape.closePath();
  const crossGeo=new THREE.ExtrudeGeometry(crossShape,{depth:.008,bevelEnabled:true,bevelSize:.003,bevelThickness:.003,bevelSegments:2,steps:1});
  const cross=mesh(vane,crossGeo,black,[0,.025,0],'Aleta_horizontal');cross.rotation.x=-Math.PI/2;
  screw(vane,[0,0,.102],'z',.014);

  // Open rain housing; raised funnel exposes the tipping-bucket mechanism.
  const rain=part('rain','Cuerpo_pluviometro',[0,1.945,-1.08]);
  lathe(rain,[[.443,-.305],[.465,-.305],[.474,-.292],[.474,.290],[.468,.305],[.443,.305],[.443,-.305]],white,[0,0,0],'Carcasa_abierta',96);
  cylinder(rain,.447,.447,.025,white,[0,-.300,0],'Fondo_pluviometro',80);
  ring(rain,.446,.009,white,[0,.298,0],'Borde_superior');
  ring(rain,.455,.007,white,[0,-.299,0],'Junta_inferior');
  const labelMaterial=white.clone();labelMaterial.name='Hiotera_Label';
  const brandLabel=mesh(rain,new THREE.CylinderGeometry(.477,.477,.44,64,1,true,-.72,1.44),labelMaterial,[0,0,0],'Etiqueta_Hiotera');brandLabel.rotation.y=Math.PI;
  for(let i=0;i<28;i++){const a=i*Math.PI*2/28;const hole=cylinder(rain,.009,.009,.002,rubber,[Math.cos(a)*.367,-.316,Math.sin(a)*.367],'Respiradero',10);}
  for(let i=0;i<3;i++){const a=i*Math.PI*2/3;const pad=box(rain,.15,.014,.025,rubber,[Math.sin(a)*.437,.281,Math.cos(a)*.437],'Apoyo_embudo',.003);pad.rotation.y=a;}
  // Inner pillars, axle and two shallow scoops. They remain entirely inside the housing.
  for(const x of [-.205,.205]){box(rain,.033,.175,.11,white,[x,-.180,0],'Soporte_balancin',.010);screw(rain,[x,-.276,.052]);}
  rod(rain,[-.245,-.073,0],[.245,-.073,0],.012,silver,'Eje_del_balancin');
  const bucket=new THREE.Group();bucket.name='Balancin_del_pluviometro';bucket.rotation.x=.095;rain.add(bucket);
  for(const z of [-.15,.15]){
    const scoop=mesh(bucket,new THREE.SphereGeometry(.194,32,14,0,Math.PI*2,Math.PI/2,Math.PI/2),white,[0,-.052,z],'Cazoleta_basculante');scoop.scale.set(.69,.42,1.02);scoop.material=white.clone();scoop.material.side=THREE.DoubleSide;
    const lip=mesh(bucket,new THREE.TorusGeometry(.193,.008,6,48),white,[0,-.052,z],'Borde_cazoleta');lip.rotation.x=Math.PI/2;lip.scale.x=.69;lip.scale.y=1.02;
  }
  box(bucket,.268,.061,.024,white,[0,-.039,0],'Separador_balancin',.006);
  box(bucket,.028,.070,.548,white,[0,-.11,0],'Nervio_balancin',.005);
  box(rain,.19,.019,.12,white,[0,-.27,.28],'Base_sensor_lluvia',.008);

  const funnel=part('funnel','Embudo_colector',[0,2.135,-1.08]);
  // A closed thin-walled lathe: exterior shell, lip, interior cone and open outlet.
  lathe(funnel,[[.049,-.126],[.067,-.126],[.067,-.103],[.455,.111],[.493,.142],[.498,.187],[.498,.215],[.479,.215],[.479,.184],[.464,.149],[.048,-.100],[.049,-.126]],innerBlack,[0,0,0],'Embudo_hueco',112);
  ring(funnel,.488,.008,black,[0,.214,0],'Borde_embudo');
  lathe(funnel,[[.278,-.002],[.292,-.002],[.292,-.099],[.278,-.099],[.278,-.002]],black,[0,-.017,0],'Collarin_inferior',72);
  for(let i=0;i<3;i++){const a=i*Math.PI*2/3;const tab=box(funnel,.038,.045,.023,black,[Math.cos(a)*.292,-.078,Math.sin(a)*.292],'Pestana_cierre',.004);tab.rotation.y=-a;}

  const shield=part('shield','Garita_de_lamas',[0,1.315,-1.08]);
  cylinder(shield,.13,.13,.449,ivory,[0,-.01,0],'Cuerpo_interior_garita');
  const plateProfile=[[.112,.021],[.195,.045],[.253,.033],[.294,-.006],[.302,-.026],[.294,-.035],[.255,-.027],[.174,.007],[.112,.010],[.112,.021]];
  for(let i=0;i<6;i++){const y=.216-i*.080;lathe(shield,plateProfile,ivory,[0,y,0],`Lama_${i+1}`,64);}
  lathe(shield,[[.113,.021],[.229,.021],[.280,-.006],[.302,-.029],[.299,-.052],[0,-.052],[0,-.035],[.113,-.017],[.113,.021]],ivory,[0,-.263,0],'Tapa_inferior',64);
  cylinder(shield,.099,.128,.090,ivory,[0,.272,0],'Cuello_garita');
  for(const x of [-.13,.13]){const head=screw(shield,[x,-.316,0],'y',.019);head.rotation.z=Math.PI;}

  const anchors={
    anemometer:new THREE.Vector3(-.22,.11,.10),
    vane:new THREE.Vector3(.28,.11,0),
    funnel:new THREE.Vector3(.39,.21,.08),
    rain:new THREE.Vector3(.40,.05,.08),
    shield:new THREE.Vector3(.27,-.01,.03),
    chassis:new THREE.Vector3(-.30,.08,.07),
    mount:new THREE.Vector3(.07,1.0,.04)
  };
  function setExplosion(t){const p=THREE.MathUtils.clamp(t,0,1);for(const key of Object.keys(parts)){parts[key].position.copy(assembled[key]).addScaledVector(offsets[key],p);}root.updateMatrixWorld(true);}
  root.traverse(o=>{if(o.isMesh)o.userData.part=o.parent?.userData?.part||o.userData.part;});
  return {root,parts,rotor,vane,setExplosion,anchors,assembled,offsets};
}
